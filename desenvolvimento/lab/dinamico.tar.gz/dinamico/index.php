<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Script Error</title>
  </head>
  <body>
    <div id="menu">
     	<a href="index.php">Home</a>
     	<a href="index.php?p=aboutus">About us</a>
     	<a href="index.php?p=contactus">Contact us</a>
     	<a href="index.php?p=news">News</a>
    </div>

    <div id="content">
    	<?php
    	$pages_dir = 'pages';
    	if (!empty($_GET['p']))
    	{
    		$pages = scandir($pages_dir, 0);
    		unset($pages[0], $pages[1]);

    		$p = $_GET['p'];

    		if (in_array($p.'.inc.php', $pages))
    		{
    			include($pages_dir.'/'.$p.'.inc.php');
    		}
    		else
    		{
    			echo "Sorry, page not found.";
    		}
    	}
    	else
    	{
    		include($pages_dir.'/home.inc.php');
    	}

    	?>    	
    </div>
  </body>
</html>
